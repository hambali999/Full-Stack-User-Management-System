import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

//THIS IS BUILDING THE REST CLIENT, DATHENA BY BALI
export class UserService {

  private baseUrl = 'http://localhost:8080/springboot-crud-rest/api/v1/users';

  constructor(private http: HttpClient) { }

  //GET USER BY BALI
  getUser(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  //CREATE USER BY BALI
  createUser(user: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`, user);
  }

  //UPDATE USER BY BALI
  updateUser(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/${id}`, value);
  }

  //DELETE USER BY BALI
  deleteUser(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`, { responseType: 'text' });
  }

  //GET LIST OF USERS BY BALI
  getUsersList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }
}
